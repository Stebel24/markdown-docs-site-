# Publishing via GitHub Pages

1. Go to your repository’s **Settings**.  
2. Scroll to **GitHub Pages**.  
3. Under "Source", select the `main` branch.  
4. Click **Save**.  
5. Your website will be live at `https://yourusername.github.io/markdown-docs-site/`.
