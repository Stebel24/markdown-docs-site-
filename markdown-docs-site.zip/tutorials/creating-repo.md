# Creating a GitHub Repository

1. Log in to your GitHub account.  
2. Click **New Repository**.  
3. Name it `markdown-docs-site`.  
4. Add a README file.  
5. Click **Create Repository**.
