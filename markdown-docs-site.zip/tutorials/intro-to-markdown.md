# Introduction to Markdown

Markdown is a lightweight markup language used to format text on the web.  
It’s easy to read, write, and convert to HTML.

## Syntax Examples
- **Bold:** `**text**`
- *Italic:* `*text*`
- [Links](https://www.markdownguide.org)
- `Inline code`
