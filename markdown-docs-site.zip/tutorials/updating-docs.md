# Updating Documentation

1. Make edits to any `.md` file.  
2. Stage and commit your changes:
   ```bash
   git add .
   git commit -m "Updated documentation"
   git push origin main
   ```
3. Refresh your GitHub Pages site to see the updates.
